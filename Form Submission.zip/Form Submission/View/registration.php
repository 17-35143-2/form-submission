<?php
include('../control/registrationcheck.php');

?>
<!DOCTYPE html>
<html>
<head><title>Registration Form</title>
</head>
<body>
<h1>Registration Form</h1>
<h1 style="text-align:center; color:MediumSeaGreen" id="header"> Registration Form</h1>
<table style="background-color:#00FF00">

<fieldset>
            <legend style="text-align:center; font-size:35px;  color:#B8860B"><b> Registration </b></legend>
            
<fieldset>
<legend>Basic Information</legend>
<b style="font-size:23px; color:white"> First Name:  &nbsp&nbsp&nbsp</b> <input type="text" name="fname"><?php echo $fnameError; ?><hr/> <br>

<b style="font-size:23px; color:white"> Last Name:  &nbsp&nbsp&nbsp</b> <input type="text" name="lname"><?php echo $lnameError; ?><hr/> <br>


<label for="gender"></label><?php echo $genderError; ?><br><br>
                                <input type="radio" name="gender" id="male" value="male" > <b style="font-size:23px; color:white">Male</b>
                            
                                <input type="radio" name="gender" id="female" value="female"><b style="font-size:23px; color:white"><b> Female</b>
                          
                                <input type="radio" name="gender" id="female" value="female"><b style="font-size:23px; color:white"> <b> Other </b>

  
  
    <b style="font-size:23px; color:white">Date of Birth:  &nbsp  </b><input type="date" id="DOB" name="DOB" ><?php echo $DOBError; ?><br>

    <b style="font-size:23px; color:white">Religion:&nbsp</b><select name="religion" id="religion"><?php echo $religionError; ?>
                            <option value="Religion">Please Choose Religion</option>
                            <option value="Islam">Islam</option>
                            <option value="Christianity">Christianity</option>
                            <option value="Buddhism">Buddhism</option>
                            <option value="Hinduism">Hinduism</option>
                            
                        </select>

                        </fieldset><br>


                        <fieldset>
<legend>Contact Information</legend>


Present Address:<textarea rows="3" cols="20"></textarea>  <br> <br><br>
Permannent Address:<textarea rows="3" cols="20"></textarea>  <br> <br><br>

Phone Number:<input type="tel" id="phone" name="phone" ><br> <br>


  <b style="font-size:23px; color:white"> Email: &nbsp&nbsp&nbsp   </b> <input type="email" name="email"><?php echo $emailError; ?><hr/> <br>
      

  <a href="http://localhost/Mycode/personal_info.php" target="_blank">Personal Website Link</a>

</fieldset>

<fieldset>
<legend>Academic Information:</legend> 
  <b style="font-size:23px; color:white"> User Name:  &nbsp&nbsp </b> <input type="text" name="username"><?php echo $usernameError; ?><hr/><br>



<b style="font-size:23px; color:white">  Password:  &nbsp&nbsp    </b> <input type="password" name="password"><?php echo $passwordError; ?> <hr/> <br>



</fieldset><br><br>
 <input name="submit" type="submit" value="Submit">
 </fieldset>
</form>


</body>
</html>